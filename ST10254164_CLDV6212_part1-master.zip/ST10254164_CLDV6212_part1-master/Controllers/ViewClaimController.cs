﻿using Microsoft.AspNetCore.Mvc;

namespace ST10254164_CLDV6212_GR2_part1.Controllers
{
    public class ViewClaimController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
