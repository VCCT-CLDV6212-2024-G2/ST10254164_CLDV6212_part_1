The first part in a POE based on cloud computing and web design
![Screenshot 2024-08-18 200852](https://github.com/user-attachments/assets/8ea1fba3-705c-482f-8a58-fce267ae43af)
