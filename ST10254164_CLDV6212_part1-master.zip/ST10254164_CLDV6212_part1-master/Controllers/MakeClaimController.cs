﻿using Microsoft.AspNetCore.Mvc;

namespace ST10254164_CLDV6212_GR2_part1.Controllers
{
    public class MakeClaimController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
